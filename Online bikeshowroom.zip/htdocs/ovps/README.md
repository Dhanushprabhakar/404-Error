# E-Voting-System
An online voting system (website) developed using HTML5, CSS, and Javascript for the front end of the website and PHP and MySQL for the backend.
